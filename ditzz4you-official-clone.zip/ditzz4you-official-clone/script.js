function toWA(message, phone='6285609018981'){
  const encoded = encodeURIComponent(message);
  window.location.href = `https://wa.me/${phone}?text=${encoded}`;
}

function handleOrderSubmit(formId, phone='6285609018981'){
  const form = document.getElementById(formId);
  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const fd = new FormData(form);
    let msg = `*Pemesanan Baru*%0A`;
    for (const [k,v] of fd.entries()){
      if(k === 'bukti') continue;
      msg += `• ${k}: ${v}%0A`;
    }
    toWA(msg, phone);
  });
}

function copyText(id){
  const el = document.getElementById(id);
  navigator.clipboard.writeText(el.textContent.trim());
  const btn = document.querySelector(`[data-copy='${id}']`);
  if(btn){ const text = btn.innerText; btn.innerText='Disalin ✓'; setTimeout(()=>btn.innerText=text,1200);}
}
